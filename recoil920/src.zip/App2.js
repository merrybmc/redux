import React from 'react';
import Router from './Router';

export default function App2() {
  return (
    <div>
      <Router />
    </div>
  );
}
