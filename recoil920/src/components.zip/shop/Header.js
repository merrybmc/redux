import React from 'react';

export default function Header() {
  return <div>shop Header</div>;
}
