import React from 'react';

export default function Article() {
  return <div>shop Article</div>;
}
